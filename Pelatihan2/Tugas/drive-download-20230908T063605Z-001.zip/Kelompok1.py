soal = {
    "001": "alfamidi",
    "002": (
        1,
        2,
        [
            "001",
            {
                "100": "Tangerang",
                "200": (
                    "FTI",
                    "Alfamaret",
                ),
                "300": {
                    "004": "Magang",
                    "005": (
                        6,
                        7,
                        [
                            "001",
                            {"100": "Training", "200": ("Lawson", "Alfamart")},
                            "003",
                        ],
                        9,
                        10,
                    ),
                    "006": "di",
                },
            },
            "003",
        ],
        4,
        5,
    ),
    "003": "aladin",
}

output = "Magang Training Alfamart di Tangerang"