"""
Anggota Kelompok 6:
    Albertus Bima Krisnawan
    Usman Syach
    Ega Fitri Yudha
    Rizky Nandang Pratama
    Ical Ferin Balino
"""

soal = {
    "001": "alfamidi",
    "002": (
        1,
        2,
        [
            "001",
            {
                "100": "Tangerang",
                "200": (
                    "FTI",
                    "Alfamaret",
                ),
                "300": {
                    "004": "Magang",
                    "005": (
                        6,
                        7,
                        [
                            "001",
                            {"100": "Training", "200": ("Lawson", "Alfamart")},
                            "003",
                        ],
                        9,
                        10,
                    ),
                    "006": "di",
                },
            },
            "003",
        ],
        4,
        5,
    ),
    "003": "aladin",
}

# Diperpendek
# # output = "Magang Training Alfamart di Tangerang"
def cariKata():
    list2 = soal['002'][2][1]['100'] # tangerang
    list3 = soal['002'][2][1]['300']['005'][2][1]['200'][1] # alfamart
    list4 = soal['002'][2][1]['300']['005'][2][1]['100'] # training
    listMagang = soal['002'][2][1]['300']['004'] # magang
    listDi = soal['002'][2][1]['300']['006']# di
    
    print (f"{listMagang} {list4} {list3} {listDi} {list2}")
    
cariKata()


# # output = "Magang Training Alfamart di Tangerang"

# def magang():
#     listMagang = soal['002'][2][1]['300']['004'] # magang
#     print(listMagang, end=' ')

# def training():
#     listTraining = soal['002'][2][1]['300']['005'][2][1]['100'] # training
#     print(listTraining, end=' ')

# def alfamart():
#     listAlfamart = soal['002'][2][1]['300']['005'][2][1]['200'][1] # alfamart
#     print(listAlfamart, end=' ')

# def di():
#     listDi = soal['002'][2][1]['300']['006']# di
#     print(listDi, end=' ')

# def tangerang():
#     listTangerang = soal['002'][2][1]['100'] # tangerang
#     print(listTangerang,end=' ')

# def cetak():
#     magang()
#     training()
#     alfamart()
#     di()
#     tangerang()
    
# cetak()



