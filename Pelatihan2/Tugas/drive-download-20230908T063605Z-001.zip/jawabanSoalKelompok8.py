var  =  ['trainingalfamart', 
          (
           {'kelompok' : [1, 2, 4, 5, 6, 7, 8]},
           {'nama':'Udin', 'umur' : 21, 'kampus' : 'UKDW'}, 
           {'nama':'Andre','umur' : 20, 'kampus' : 'UKDW'}, 
           {'nama':'Messi', 'umur' : 19, 'kampus' : 'UKSW'}, 
           {'nama':'Ozil', 'umur' : 21, 'kampus' : 'UKSW'}
          )
        ]

# """
#     a. Perkenalkan kami adalah Udin, Andre, Messi, dan Ozil. Kami mahasiswa angkatan 2020 dari 'UKSW/UKDW', 
#        siap untuk berkolaborasi dan berkontirbusi di Training Alfamart 2023 
       
#     b. Saya Andre di usia saya yang ke 20, saya bertemu dengan Messi kelompok 8 ketika Training yang diselenggarakan Alfamart.
       
# """



def perkenalan():
  print(f"Perkenalkan kami adalah {var[1][1]['nama']}, {var[1][2]['nama']}, {var[1][3]['nama']}, dan {var[1][4]['nama']}. Kami mahasiswa angkatan 2020 dari '{var[1][3]['kampus']}/{var[1][1]['kampus']}', siap untuk berkolaborasi dan berkontribusi di Training Alfamart 2023")

def jawabanB():
  txtB = "Saya {} di usia yang ke {}, saya bertemu dengan {} kelompok {} ketika Training yang diselenggarakan Alfamart."
  jawabanB = txtB.format(var[1][2]['nama'], var[1][2]['umur'], var[1][3]['nama'],var[1][0]['kelompok'][6])
  return jawabanB

a = perkenalan()
b = jawabanB()
print(b)


'''untuk jawaban a versi 2'''
# def getName():
#     names = []
#     for i in var[1][1:4]:
#         names.append(i['nama'])  # Extract names from the list
#     return names

# def getKampus():
#     kampus = set()
#     for i in var[1][1:]:
#         kampus.add(i['kampus'])  # Extract names from the list
#     return kampus

# def toText(names, kampus):
#     intro_text = f"Perkenalkan kami adalah {', '.join(names)} dan {var[1][4]['nama']}. Kami mahasiswa angkatan 2020 dari {'/'.join(kampus)}, siap untuk berkolaborasi dan berkontribusi di Training Alfamart 2023."
#     return intro_text

# names = getName()
# kampus = getKampus()
# intro_text = toText(names, kampus)
# print(intro_text)



'''
soal kelompok 8 di jawab oleh kelompok 7
    - Mikha Kurnia Anggi Purbaningtyas
    - Aditya Wisnu Permana
    - Caroluce Ricky Harkis Nowo
    - Michael Antonius Hartono
    - Giovanni Harrius
'''