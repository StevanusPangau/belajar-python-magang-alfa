list_kata = ['alfamart', {'a': [3,8], 'b': 2023}, ('training', 'pada', {'c': 'kelompok', 'd': 'pelatihan'}, 'membuat'), 'soal', 'peserta', ('tanggal', 'lain', 'menjadi'), {'e': 'dibagi'}]

# Soal a
# Pada hari ke 3 pelatihan peserta dibagi menjadi 8 kelompok.
# Soal b
# Kelompok 3 membuat soal ini untuk peserta lain di training Alfamart pada tanggal 8 September 2023.