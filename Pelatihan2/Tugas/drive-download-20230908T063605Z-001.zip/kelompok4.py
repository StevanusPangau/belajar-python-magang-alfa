soal1 = [['o', 'i', 'r'], "sUkA", {'1': 'ber', '2': 'ena', '3': 'ng'}, ['Di', 'padding', 'TON'], {'1': 'jam', '2': 'jam', '3': 'jam'}]
# Rio suka berenang di Paddington 3 jam

soal2 = [('train', 'trening', 'tiraining', 'ing'), ['a', 'L', 'f', 'A', 'm','A', 'r', 'T', '.'], {'di': 1, 'ada': 2, 'kan': 3}, "selama", ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'], "HarI"]
# Training alfamart diadakan selama 10 hari




