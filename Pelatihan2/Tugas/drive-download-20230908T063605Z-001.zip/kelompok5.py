list_alfamart = ([{'saya':'peserta','asal':'uksw/ukdw','dari':'berasal'},2],(3,'magang'),[({1:'training',2:'periode'},'mahasiswa'),20],'alfamart')
#Saya peserta TRAINING ALFAMART Berasal dari UKSW/UKDW
#Saya, Berasal (wajib huruf kapital)
#TRAINING , ALFAMART, dan UKSW/UKDW (wajib uppercase)

#Mahasiswa magang UKSW/UKDW peserta Training Alfamart periode 2023
#ketentuannya UKSW/UKDW haru huruf besar
#Mahasiswa, Training dan Alfamart huruf depannya harus kapital

