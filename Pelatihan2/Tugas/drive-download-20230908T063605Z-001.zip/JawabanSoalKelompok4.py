# Jawab dari soal kelompok 4
# Yang menjawab adalah kelompok 3
# Anggota :
# 1. Bayu Ponco Raharjo
# 2. Ambrosius Ludang GA.
# 3. Leonard Surya Adji
# 4. Bayu Andy Daniswara
# 5. Alief Yuwastika Firmandicky

soal1 = [['o', 'i', 'r'], "sUkA", {'1': 'ber', '2': 'ena', '3': 'ng'}, ['Di', 'padding', 'TON'], {'1': 'jam', '2': 'jam', '3': 'jam'}]
# Rio suka berenang di Paddington 3 jam
print("Soal a:")
# Cara 1
def jawab1a():
    print("Cara 1:")
    print(soal1[0][2].upper() + soal1[0][1] + soal1[0][0], soal1[1].lower(), soal1[2]['1'] + soal1[2]['2'] + soal1[2]['3'], soal1[3][0].lower(), soal1[3][1].capitalize() + soal1[3][2].lower(), len(soal1[4]), soal1[4]['1'])
jawab1a()

# Cara 2
def jawab1b():
    print("Cara 2:")
    soal1 = [['o', 'i', 'r'], "sUkA", {'1': 'ber', '2': 'ena', '3': 'ng'}, ['Di', 'padding', 'TON'], {'1': 'jam', '2': 'jam', '3': 'jam'}]
    rio = soal1[0][2].upper() + soal1[0][1]  + soal1[0][0]
    suka = soal1[1].lower()
    berenang = soal1[2]['1'] + soal1[2]['2'] + soal1[2]['3']
    paddington = soal1[3][0].lower() + " " + soal1[3][1].capitalize() + soal1[3][2].lower()
    jam = str(len(soal1[4]['1'])) + " " +soal1[4]['1']
    return rio + " "  + suka + " " + berenang + " " + paddington + " " + jam
hasil = jawab1b()
print(hasil)

soal2 = [('train', 'trening', 'tiraining', 'ing'), ['a', 'L', 'f', 'A', 'm','A', 'r', 'T', '.'], {'di': 1, 'ada': 2, 'kan': 3}, "selama", ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'], "HarI"]

# Training alfamart diadakan selama 10 hari
def jawab2():
    print("Soal b:")
    String = str.title(soal2[0][0]+soal2[0][3] ) 

    sAlfa = ""
    for i in soal2[1]:
        sAlfa = sAlfa + i

    sAlfa = str.lower(sAlfa[:-1])

    lsiDia =  list(soal2[2].keys())


    dia =""
    for i in lsiDia:
        dia = dia+i

    hari = str.lower(soal2[5])

    return print(String,sAlfa,dia,soal2[3],len(soal2[4]),hari)
jawab2()