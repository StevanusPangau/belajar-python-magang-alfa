aa = "gess"
training_info = {
    "title" : "magang alfamart",
    "waktu": "1 september 2023 - 20 september 2023",
    "lokasi": "Pt Sumber alfaria Trijaya",
    "peserta": 39,
    "training_tugas": [
        f"diminta buat soal saat training {aa} ",
        "Alfamart tower alam sutera",
        ["pengenalan sistem kasir", "manajemen stok", "pelayanan pelanggan", "oden"],
    ],
    "trainer": (
        "Pak Reza",
        "kak alpha",
        "kak mario",
        "kak leo"
    ),
}

#soal 3a
#Materi Pengenalan Sistem Kasir adalah Pak Reza, Pengajar Manajemen Stok adalah Kak Alpha 

#soal 3 b
# Saya menjadi peserta training Alfamart di Pt Sumber Alfaria Trijaya
