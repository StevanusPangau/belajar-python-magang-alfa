aa = "gess"
training_info = {
    "title": "magang alfamart",
    "waktu": "1 september 2023 - 20 september 2023",
    "lokasi": "Pt Sumber alfaria Trijaya",
    "peserta": 39,
    "training_tugas": [
        f"diminta buat soal saat training {aa} ",
        "Alfamart tower alam sutera",
        ["pengenalan sistem kasir", "manajemen stok", "pelayanan pelanggan", "oden"],
    ],
    "trainer": ("Pak Reza", "kak alpha", "kak mario", "kak leo"),
}

# soal 3a
# Materi Pengenalan Sistem Kasir adalah Pak Reza, Pengajar Manajemen Stok adalah Kak Alpha

# soal 3 b
# Saya menjadi peserta training Alfamart di Pt Sumber Alfaria Trijaya


def desain1(**line):
    pengenalan = line["training_tugas"][2][0]
    trainer = line["trainer"][0]
    trainer2 = line["trainer"][1]
    stok = line["training_tugas"][2][1]
    # for key, val in args.items():
    #     print(key, " = ", val)
    return (
        "Materi "
        + pengenalan.title()
        + " adalah "
        + trainer
        + ", Pengajar "
        + stok.title()
        + " adalah "
        + trainer2.title()
    )


def desain2(**line):
    trainingTugas = line["training_tugas"][0]
    alfamart = line["title"]
    lokasi = line["lokasi"]
    # for key, val in args.items():
    #     print(key, " = ", val)
    return (
        "Saya menjadi peserta "
        + trainingTugas[23:31]
        + " "
        + alfamart[7:].title()
        + " di "
        + lokasi.title()
    )


print("SOAL 3A : ", desain1(**training_info))
print("SOAL 3B : ", desain2(**training_info))

"""
Anggota Kelompok 1 :
Georgio Nicky Rumampuk(672020267)
Muhamad Rizky Dhean Aryanto (672020289)
Oktaviano Miftahul Maf'arif (672020289)
Sarah Larasati (672020174)
Silverius Stanic Setyaputra (72200383)
"""