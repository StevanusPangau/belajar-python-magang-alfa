"""
Kelompok 5 : 
Joseph Heykel Prabawa
Daniel Richardo
Tifano Eng Ogotan
Mahesa Rio Aditya
Ryan Agung Iskandar
"""


# Kelompok - 2
var = ['training',
       'uk', 
       {'salatiga': 'sw', 'dw': 'yogyakarta', 'huruf': ('t', 'B', 'K')}, 
       ['alfa', 'mart', 'pt,', 'ria']]

# output a : Para Mahasiswa UKDW Dan UKSW mengikuti Magang Di Perusahaan Pt. SUMBER ALFARiA TRIJAYA, Tbk
# output b : Training AlfAmArt Dilakukan Pada Tanggal 1 September 2023 - 19 SeptembeR 2023

#function replace comma with dot
def Replace2(list):
    for i in range(len(list)):
        list[i] = list[i].replace(',', ".")
    return list

# Jawaban 
def outputA(var):
    test = list(var[3])
    pt = Replace2(test)

    #print(Replace2(test))
    # print(test)
    keydict2 = list(var[2].keys())
    valuedict2 = list(var[2].values())
    #print(keydict2)
    #print(valuedict2) 

    # output a : Para Mahasiswa UKDW Dan UKSW mengikuti Magang Di Perusahaan Pt. SUMBER ALFARiA TRIJAYA, Tbk

    print('Para Mahasiswa ' + var[1].upper() + str(keydict2[1]).upper()+ ' Dan ' + var[1].upper() + str(valuedict2[0]).upper() + ' ' 
        + 'mengikuti Magang Di Perusahaan ' + pt[2].title() + ' SUMBER ' 
        + var[3][0].upper() + var[3][3][:1].upper() + var[3][3][1:2] + var[3][3][-1:].upper() + " TRIJAYA" + var[3][2][-1:] + ' ' + str(valuedict2[2][0]).upper() + str(valuedict2[2][1]).lower() + str(valuedict2[2][2]).lower())
        #   + var[3][0].upper() + var[3][1].upper() + var[3][3].upper() + ', ' + var[4] + ' ' + var[5] + ' ' + var[6].upper())
outputA(var)


# output b : Training AlfAmArt Dilakukan Pada Tanggal 1 September 2023 - 19 SeptembeR 2023
def answerFunc(var):
    alfamart = var[3][0] + var[3][1]
    alfamart1 = ""
    for alpha_a in alfamart:
        if alpha_a == "a":
            alfamart1 = alfamart1 + "A"
        else:
            alfamart1 = alfamart1 + alpha_a
    return print(
        var[0].capitalize(),
        alfamart1,
        "Dilakukan",
        "Pada",
        "Tanggal",
        "1 September 2023",
        "-",
        "19 SeptembeR",
        "2023",
    )
answerFunc(var)

