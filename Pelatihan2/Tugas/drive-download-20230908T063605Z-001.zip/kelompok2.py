# Kelompok - 2
var = ['training', 'uk', {'salatiga': 'sw', 'dw': 'yogyakarta', 'huruf': (
    't', 'B', 'K')}, ['alfa', 'mart', 'pt,', 'ria'], '20', '23', 'september']

# output a : Para Mahasiswa UKDW Dan UKSW mengikuti Magang Di Perusahaan Pt. SUMBER ALFARiA TRIJAYA, Tbk
# output b : Training AlfAmArt Dilakukan Pada Tanggal 1 September 2023 - 19 SeptembeR 2023
