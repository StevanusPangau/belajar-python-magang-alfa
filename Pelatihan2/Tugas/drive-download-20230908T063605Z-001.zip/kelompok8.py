var  =  ['trainingalfamart', 
          (
           {'kelompok' : [1, 2, 4, 5, 6, 7, 8]},
           {'nama':'Udin', 'umur' : 21, 'kampus' : 'UKDW'}, 
           {'nama':'Andre','umur' : 20, 'kampus' : 'UKDW'}, 
           {'nama':'Messi', 'umur' : 19, 'kampus' : 'UKSW'}, 
           {'nama':'Ozil', 'umur' : 21, 'kampus' : 'UKSW'}
          )
        ]

"""
    a. Perkenalkan kami adalah Udin, Andre, Messi, dan Ozil. Kami mahasiswa angkatan 2020 dari 'UKSW/UKDW', 
       siap untuk berkolaborasi dan berkontirbusi di Training Alfamart 2023 
       
    b. Saya Andre di usia saya yang ke 20, saya bertemu dengan Messi kelompok 8 ketika Training yang diselenggarakan Alfamart.
       
"""