soal = ['training', {'angka': [1, 2, 3, 12]}, ('aku', 'alfamart', 'tahu', 'you', {'huruf': ['i', 'know', 'kata']})]

# Output 1a
print(f"    {soal[1]['angka'][0]} {soal[2][0]} {soal[2][2]} {soal[1]['angka'][3]}")
print(f"    {soal[1]['angka'][1]} {' '.join(soal[2][4]['huruf'])}")

# Output 1b
print(f"    {soal[1]['angka'][2]} {soal[2][0]} {soal[2][2]} {soal[0]} {soal[2][1]}")

"""
    output 
    1a. 
        1 aku tahu 12 (enter)
        2 i know you
    1b.
        3 aku tahu training alfamart
"""

"""
    soal kelompok 6 dijawab kelompok 4
    Kelompok 4 :
    Aryudha Willy P.H (672020232)
    Titis Aditya P.W (672020044)
    Edwin Duta Ramadhan (672020272)
    Timoty Arif Kurniawan (672020104)
    Finda Affandi (672020113)


"""