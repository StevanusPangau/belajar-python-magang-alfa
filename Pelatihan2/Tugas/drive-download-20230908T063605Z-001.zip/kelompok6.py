soal = ['training', {'angka': [1,2,3,12]}, ('aku', 'alfamart', 'tahu', 'you', {'huruf' : ['i', 'know', 'kata']})]

"""
    output 
    1a. 
        1 aku tahu 12 (enter)
        2 i know you
    1b.
        3 aku tahu training alfamart
"""
